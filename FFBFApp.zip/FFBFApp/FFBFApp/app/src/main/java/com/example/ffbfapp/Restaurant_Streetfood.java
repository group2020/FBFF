package com.example.ffbfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Restaurant_Streetfood extends AppCompatActivity {

    Button rest, street, add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant__streetfood);
        rest = findViewById(R.id.btn_REST);
        street = findViewById(R.id.btn_STREET);
        add = findViewById(R.id.btn_addnew);

        //YOU NEED TO MAKE NAVIGATION FROM THE RESTAURANT/STREETFOOD TO THE RESTAURANT LIST.


        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(Restaurant_Streetfood.this, list.class);
                ii.putExtra("TYPE", "RESTAURANT");
                startActivity(ii);

            }
        });



        //NAVIGATION FROM RESTAURANT/STREETFOOD ACTIVITY TO THE LIST OF THE STREETFOOD ACTIVITY.
        street.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(Restaurant_Streetfood.this, list.class);
                ii.putExtra("TYPE", "STREETFOOD");
                startActivity(ii);

            }
        });

        //NAVIGATION FROM RESTAURANT/STREETFOOD ACTIVITY TO THE Upload NEW EATERY ACTIVITY.
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent n = new Intent(Restaurant_Streetfood.this, Login.class);
                startActivity(n); }
        });
    }
}