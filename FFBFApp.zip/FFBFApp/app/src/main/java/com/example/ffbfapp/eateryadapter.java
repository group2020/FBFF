package com.example.ffbfapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class eateryadapter extends RecyclerView.Adapter <eateryadapter.Holder>
{

    ArrayList <Streetfood> list;
    Holder.CardInterface listener;

    public eateryadapter(ArrayList<Streetfood> list, Holder.CardInterface _listener) {
        this.list = list;
        listener = _listener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.eaterycard, parent, false);
        Holder holder = new Holder(v, listener);
        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.tv.setText(list.get(position).getName());
        Picasso.get().load(list.get(position).getImageURL()).fit().into(holder.iv);

    }

    @Override
    //This method will get me the number of the cards
    public int getItemCount() {
        return list.size();
    }

    public static class Holder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        ImageView iv;
        TextView tv;
        CardInterface listener;
        public Holder(@NonNull View itemView, CardInterface _listener) {
            super(itemView);
            iv = itemView.findViewById(R.id.iv_list_image);
            tv = itemView.findViewById(R.id.tv_list_name);
            listener = _listener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            listener.onCardClick(getAdapterPosition());
        }

        public interface CardInterface
        {
            public void onCardClick (int i);

        }
    }
}
