package com.example.ffbfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

public class UploadDescription extends AppCompatActivity {

    EditText name, desc;
    Button save;
    Button next;
    DatabaseReference dbref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_description);
        name = findViewById(R.id.et_name);
        desc = findViewById(R.id.et_desc);
        save = findViewById(R.id.btn_save);
        next = findViewById(R.id.btn_continue);
        dbref = FirebaseDatabase.getInstance().getReference("Streetfood");
        Intent i = getIntent();
        final String url = i.getStringExtra(Upload.URL);

        //Navigation back from the upload description page to the restaurant/streetfood activity.
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(UploadDescription.this, Restaurant_Streetfood.class);
                startActivity(c);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Streetfood streetfood =  new Streetfood(name.getText().toString(),
                        desc.getText().toString(), url, " ", false);
                dbref.child(streetfood.getName()).setValue(streetfood);

            }
        });
    }
}