package com.example.ffbfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

public class Rating extends AppCompatActivity {

    TextView rateCount, showRating;
    EditText review;
    Button send, home;
    RatingBar ratingBar;
    float rateValue; String temp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);
        rateCount = findViewById(R.id.rateCount);
        ratingBar = findViewById(R.id.ratingBar);
        review = findViewById(R.id.review);
        send = findViewById(R.id.submitBtn);
        showRating = findViewById(R.id.showRating);
        home = findViewById(R.id.btn_home);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                rateValue = ratingBar.getRating();
                if (rateValue<=1 && rateValue>0)
                    rateCount.setText("Bad" + rateValue + "/5");
                else if (rateValue<=2 && rateValue>1)
                    rateCount.setText("Ok" + rateValue + "/5");
                else if (rateValue<=3 && rateValue>2)
                    rateCount.setText("Good" + rateValue + "/5");
                else if (rateValue<=4 && rateValue>3)
                    rateCount.setText("Very Good" + rateValue + "/5");
                else if (rateValue<=5 && rateValue>4)
                    rateCount.setText("Best" + rateValue + "/5");
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent f = new Intent(Rating.this, Restaurant_Streetfood.class);
                startActivity(f);
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = rateCount.getText().toString();
                showRating.setText("Your Rating: \n" + temp +"\n" + review.getText());
                review.setText(" ");
                ratingBar.setRating(0);
                rateCount.setText(" ");
            }
        });

    }
}