package com.example.ffbfapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class list extends AppCompatActivity implements eateryadapter.Holder.CardInterface {

    RecyclerView rv;
    RecyclerView.LayoutManager manager;
    eateryadapter adapter;
    Query dbref;
    ArrayList<Streetfood> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        rv = findViewById(R.id.id_rv);
        Intent ii = getIntent();
        String type = ii.getStringExtra("TYPE");

        dbref = FirebaseDatabase.getInstance().getReference("Streetfood").orderByChild("Type").equalTo(type);
        dbref.addListenerForSingleValueEvent(listener);

        manager = new LinearLayoutManager(list.this);
        rv.setLayoutManager(manager);



    }
    ValueEventListener listener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            for (DataSnapshot dss: snapshot.getChildren())
            {
                Streetfood Street = dss.getValue(Streetfood.class);
                list.add(Street);
            }
            adapter = new eateryadapter(list, list.this);
            rv.setAdapter(adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };

    @Override
    public void onCardClick(int i) {
        Intent intent = new Intent(list.this, Card_details.class);
        intent.putExtra("Streetfood", list.get(i));
        startActivity(intent);

    }
}