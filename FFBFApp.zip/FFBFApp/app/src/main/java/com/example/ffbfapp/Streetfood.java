package com.example.ffbfapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Streetfood implements Parcelable
{
    private String name, desc, imageURL, bookingURL;
    private boolean canBook;

    public Streetfood(String name, String desc, String imageURL, String bookingURL, boolean canBook) {
        this.name = name;
        this.desc = desc;
        this.imageURL = imageURL;
        this.bookingURL = bookingURL;
        this.canBook = canBook;
    }

    public Streetfood() {}

    protected Streetfood(Parcel in) {
        name = in.readString();
        desc = in.readString();
        imageURL = in.readString();
        bookingURL = in.readString();
        canBook = in.readByte() != 0;
    }

    public static final Creator<Streetfood> CREATOR = new Creator<Streetfood>() {
        @Override
        public Streetfood createFromParcel(Parcel in) {
            return new Streetfood(in);
        }

        @Override
        public Streetfood[] newArray(int size) {
            return new Streetfood[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getBookingURL() {
        return bookingURL;
    }

    public void setBookingURL(String bookingURL) {
        this.bookingURL = bookingURL;
    }

    public boolean isCanBook() {
        return canBook;
    }

    public void setCanBook(boolean canBook) {
        this.canBook = canBook;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(desc);
        dest.writeString(imageURL);
        dest.writeString(bookingURL);
        dest.writeByte((byte) (canBook ? 1 : 0));
    }
}
