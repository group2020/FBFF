package com.example.ffbfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class Card_details extends AppCompatActivity {
    ImageView image;
    TextView name, desc;
    Button book, view, add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_details);

        Intent i = getIntent();
        book = findViewById(R.id.btn_book);
        image = findViewById(R.id.iv_card);
        name = findViewById(R.id.tv_desc_name);
        desc = findViewById(R.id.tv_desc);
        view = findViewById(R.id.btn_view_review);
        add = findViewById(R.id.btn_add_review);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(Card_details.this, Rating.class);
                startActivity(e);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent k = new Intent(Card_details.this, ViewReview.class);
                startActivity(k);
            }
        });


        Streetfood s = (Streetfood) getIntent().getParcelableExtra("Streetfood");
        Picasso.get().load(s.getImageURL()).fit().into(image);
        name.setText(s.getName());
        desc.setText(s.getDesc());


        Streetfood street = i.getParcelableExtra("Streetfood");

        if (street.isCanBook())
        {
            book.setVisibility(View.VISIBLE);
            Toast.makeText(Card_details.this, "Restaurant is open for booking!", Toast.LENGTH_LONG).show();
        }
        else
        {
            book.setVisibility(View.INVISIBLE);
            Toast.makeText(Card_details.this, "Restaurant is too busy to accept booking!", Toast.LENGTH_LONG).show();
        }
    }

    public void setBook (View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.opentable.com/s/?covers=2&dateTime=2019-02-25%2019%3A00&metroId=72&regionIds=5316&pinnedRids%5B0%5D=87967&enableSimpleCuisines=true&includeTicketedAvailability=true&pageType=0"));
        startActivity(browserIntent);

    }
}