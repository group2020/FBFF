package com.example.ffbfapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ViewReview extends AppCompatActivity {

    Button Back, newr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_review);

        Back = findViewById(R.id.btn_back);
        newr = findViewById(R.id.btn_new_review);


        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(ViewReview.this, Card_details.class);
                startActivity(b);
            }
        });

        newr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent h = new Intent(ViewReview.this, Rating.class);
                startActivity(h);
            }
        });
    }
}